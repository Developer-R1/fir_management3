import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PolicePortalComponent } from './police-portal/police-portal.component';
import { PublicPortalComponent } from './public-portal/public-portal.component';
import { HomePageComponent } from './home-page/home-page.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,PolicePortalComponent,PublicPortalComponent,HomePageComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'fir_management_frontend';

  
}
