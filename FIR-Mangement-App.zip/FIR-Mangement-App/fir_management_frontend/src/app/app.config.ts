import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { NgModule } from '@angular/core';
import { PolicePortalComponent } from './police-portal/police-portal.component';
import { PublicPortalComponent } from './public-portal/public-portal.component';
import { HomePageComponent } from './home-page/home-page.component';
import { routes } from './app.routes';
import { provideHttpClient } from '@angular/common/http';
import { AppComponent } from './app.component';

export const appConfig: ApplicationConfig = {
  providers: [provideHttpClient(), provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes)]
};
