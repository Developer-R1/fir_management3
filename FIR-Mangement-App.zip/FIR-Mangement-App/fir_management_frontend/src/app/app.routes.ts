import { Routes,RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { PolicePortalComponent } from './police-portal/police-portal.component';
import { PublicPortalComponent } from './public-portal/public-portal.component';
import { HomePageComponent } from './home-page/home-page.component';


export const routes: Routes = [

    {path:"user/home",component:HomePageComponent},
    {path:"",redirectTo:"user/home",pathMatch:"full"},
    {path:"signup", component:PublicPortalComponent,pathMatch:"full"},
    // {path:"publicHomePage", component:PublicPortalComponent,pathMatch:"full"},
    {path: "PublicPortalSignin", component: PublicPortalComponent,pathMatch:"full"},
    {path: "PolicePortalSignin", component: PolicePortalComponent,pathMatch:"full"},
    // {path:"userSignIn", component: PublicPortalComponent,pathMatch:"full"},
    // {path:"officerSignIn", component: PublicPortalComponent,pathMatch:"full"}
    // {path:"signin", component:PublicPortalComponent,pathMatch:"full"},
    // {path:"publicProfile", component:PublicPortalComponent,pathMatch:"full"},

];



// @NgModule({
//     imports: [RouterModule.forRoot(routes)],
//     exports: [RouterModule]
//   })

//   export class AppRoutingModule { }
  
