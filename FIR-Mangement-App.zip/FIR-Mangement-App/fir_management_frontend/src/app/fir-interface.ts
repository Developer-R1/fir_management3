export interface policeAdminPortal{
    
    name: string,
    email: string,
    ID: string,
    password: string,
    phoneNumber: string,
    rank: string,
    awards: string,
    state: string,
    casesAccomplished: number,
    casesPending: number
}


export interface publicPortal{
    
    name: string,
    email: String,
    password:String,
    phoneNumber: String,
    age: Number,
    address: String,
    state: String,
}

export interface casePortal{
    case_id:Number,
    email:String,
    case_title:String,
    case_type:String,
    description:String,
    location:String,
    case_status:String,
    evidence:String
}





