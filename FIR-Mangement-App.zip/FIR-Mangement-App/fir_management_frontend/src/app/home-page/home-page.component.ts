import { Component, OnInit } from '@angular/core';
import { PublicPortalComponent } from '../public-portal/public-portal.component';
import { PolicePortalComponent } from '../police-portal/police-portal.component';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [PolicePortalComponent,PublicPortalComponent,CommonModule],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.css'
})
export class HomePageComponent implements OnInit {

  landingPage:boolean = true;
  showAllLaws:boolean=false;

  constructor(private router: Router) {}

  ngOnInit(): void {}

  goToSignUp() {
    this.router.navigate(['/signup']);  
  }

  goToSignIn() {
    this.router.navigate(['/PublicPortalSignin']);  
  }

  goToOfficerSignIn(){
    this.router.navigate(['/PolicePortalSignin']);
  }

  toShowAllLaws(){
    this.showAllLaws = true;
    this.landingPage = false;
  }

  notShowLaws(){
    this.showAllLaws = false;
    this.landingPage = true;
  }

}
