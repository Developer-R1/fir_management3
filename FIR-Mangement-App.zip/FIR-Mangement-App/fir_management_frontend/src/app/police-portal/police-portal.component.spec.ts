import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicePortalComponent } from './police-portal.component';

describe('PolicePortalComponent', () => {
  let component: PolicePortalComponent;
  let fixture: ComponentFixture<PolicePortalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PolicePortalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PolicePortalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
