import { Component, inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { policeAdminPortal, casePortal } from '../fir-interface';
import { CommonModule,Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {ActivatedRoute, Router } from '@angular/router';




@Component({
  selector: 'app-police-portal',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './police-portal.component.html',
  styleUrl: './police-portal.component.css'
})
export class PolicePortalComponent implements OnInit{

  policeList: policeAdminPortal [] = [];
  policeCaseViewList: casePortal [] = [];
  caseList: casePortal [] = [];
  email: string = '';
  password: string = '';
  passwordError: Boolean = false;
  isAuthenticated:Boolean = false;
  loading:Boolean = false;
  isSignInPage1:Boolean = true;
  profileCard:Boolean = false;


  name: string = '';
  ID: string = '';
  phoneNumber: string = '';
  rank: string = '';
  awards:string='';
  state: string = '';
  casesAccomplished:number=0;
  casesPending:number=0;

  officerLoggedIn:boolean = false;

  viewCases:boolean = false;

  showAllLaws:Boolean = false;

  isEditing:boolean=false;

  http = inject(HttpClient);

  constructor(private route: ActivatedRoute, private router: Router, private location1: Location) {}

  ngOnInit(): void {
    this.getAllPolice();
    this.getAllCases();

    this.route.url.subscribe((url) => {
      if (url[0].path === 'PolicePortalSignin') {
        this.isSignInPage1 = true;
    }
   });
  }

  getAllPolice(){
    this.http.get("http://localhost:4000/api/v1/policeportal").subscribe((res:any)=>{
      console.log(res);
      this.policeList = res;
    },
    (err)=>{
      console.log("Error in recieving the api",err);
    }
   );
  }

  onSubmit(): void{

    this.loading = true;
    this.passwordError = false;

    const user = this.policeList.find((u) => u.email === this.email);
    
    if(user){
      if (user.password === this.password) {
        this.isAuthenticated = true;
        this.passwordError = false;
        // user.state=this.state;
        this.state=user.state;
        this.name=user.name;
        this.email=user.email;
        this.ID=user.ID;
        this.password=user.password;
        this.phoneNumber=user.phoneNumber;
        this.rank=user.rank;
        this.awards=user.awards;
        this.casesAccomplished=user.casesAccomplished;
        this.casesPending=user.casesPending;

        this.location1.replaceState('/officerSignIn');
        this.ifOfficerLoggedIn();
        this.updatePoliceViewCases(user.state);
        // console.log(`${this.state}`);
        // console.log(`${user.state}`);

      } else {
        this.passwordError = true;
        this.isAuthenticated = false;
      }
    } else {
      this.passwordError = true;
      this.isAuthenticated = false;
    }

    this.loading = false;

  }

  ifOfficerLoggedIn(){
    this.isSignInPage1=false;
    this.officerLoggedIn=true;
  }

  sendOtp(): void{

    if (this.isAuthenticated){
      // console.log(`OTP sent to ${this.email}`);
    }else {
      // console.log('User not authenticated');
    }
  }


  // postForm(): void {
  
  //   const formData = {
  //     name: this.name,
  //     email: this.email,
  //     password: this.password,
  //     ID: this.ID,
  //     phoneNumber: this.phoneNumber,
  //     rank: this.rank,
  //     state: this.state
  //   };

  //   this.http.post("http://localhost:4000/api/v1/policeportal", formData).subscribe(
  //     (response) => {
  //       console.log('Form submitted successfully:', response);
  //     },
  //     (error) => {
  //       console.error('Error submitting form:', error);
  //     }
  //   );
  // }

  getAllCases(){
    this.http.get("http://localhost:4000/api/v1/caseportal").subscribe((res:any)=>{
      console.log(res);
      this.caseList = res;
      this.filterPoliceViewCases();
    },
    (err)=>{
      // console.log("Error in recieving case api",err);
    }
   );
  }

  openProfileCard(){
    this.profileCard = true;
  }

  closeProfileCard(){
    this.profileCard = false;
  }

  updatePoliceViewCases(policeState: string): void {
    this.state = policeState; 
    this.filterPoliceViewCases();   
  }

  filterPoliceViewCases(): void {
    if (this.state) {
      this.policeCaseViewList = this.caseList.filter(caseData => caseData.location === this.state);
    }
  }

  
  isViewcase(){
    this.viewCases = true;
    // console.log(`${this.state}`);
    this.updatePoliceViewCases(this.state);
    // console.log(this.policeCaseViewList);
    this.officerLoggedIn = false;
    // console.log(this.viewCases)
  }

  closeCaseView(){
    this.viewCases = false;
    this.officerLoggedIn = true;
  }

  toShowAllLaws(){
    this.showAllLaws = true;
    this.officerLoggedIn = false;
  }

  notShowLaws(){
    this.showAllLaws = false;
    this.officerLoggedIn = true;
  }

  updateCaseStatus(caseId: Number, newStatus: String): void {
    const caseData = { case_status: newStatus };

    this.http.put(`http://localhost:4000/api/v1/caseportal/${caseId}`, caseData).subscribe(
      (response: any) => {
        console.log('Case status updated successfully:', response);
        this.getAllCases(); 
      },
      (error) => {
        console.error('Error updating case status:', error);
      }
    );
  }

  enableEditing(caseData: any): void {
    this.isEditing = true;
  }

  cancelEditing(caseData: any): void {
    this.isEditing = false;
    this.getAllCases();
  }

  deleteCase(id:Number){
    this.http.delete(`http://localhost:4000/api/v1/caseportal/${id}`)
    .subscribe(
      (res: any) => {
        // console.log('FIR deleted successfully', res);
        this.getAllCases();
      },
      (err) => {
        // console.error('Error Deleting FIR:', err);
      }
    );
  }


}
