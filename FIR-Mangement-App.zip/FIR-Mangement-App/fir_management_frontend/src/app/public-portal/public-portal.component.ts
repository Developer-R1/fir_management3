import { CommonModule,Location} from '@angular/common';
import {Component,inject,OnInit } from '@angular/core';
import { publicPortal } from '../fir-interface';
import { casePortal } from '../fir-interface';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-public-portal',
  standalone: true,
  imports: [CommonModule,FormsModule,ReactiveFormsModule],
  templateUrl: './public-portal.component.html',
  styleUrl: './public-portal.component.css'
})
export class PublicPortalComponent implements OnInit{


  publicList: publicPortal [] = [];
  caseList: casePortal [] = [];
  userCaseList: casePortal [] = [];
  email: string = '';
  password: string = '';
  passwordError: Boolean = false;
  otpError:Boolean = false;
  isAuthenticated:Boolean = false;
  loading:Boolean = false;
  isSignInPage:Boolean = false;
  isSignUpPage:Boolean = false;
  userLoggedIn:Boolean = false;
  profileCard:Boolean = false;

  // otpMain:string = '1234567';
  otp: string = '';
  isSignUpPressed:Boolean = false;
  signUpOtpEntered:Boolean = false;
  

  name: string = '';
  age:number = 0;
  phoneNumber: string = '';
  address: string = '';
  state: string = '';


  userName:String = '';
  userEmail: String = '';
  userPassword: String = '';
  userPhoneNumber: String = '';
  userAge:Number = 0;
  userAddress: String = '';
  userState: String = '';

  isOpenCaseForm:Boolean = false; 

  email1: string = '';
  case_title: string = '';
  case_type: string = '';
  description: string = '';
  location: string = '';
  case_status: string = 'Not yet Seen';
  selectedFile: File | null = null;
  imageBase64: string = '';

  viewCases:Boolean = false;
  firEmailError:Boolean = false;
  showAllLaws:Boolean = false;


  theOtp:string = '';


  nameError: string = '';
  emailError: string = '';
  passwordError1: string = '';
  phoneError: string = '';
  ageError: string = '';
  addressError: string = '';
  stateError: string = '';
  otpError1: string = '';



  http = inject(HttpClient);

  constructor(private route: ActivatedRoute, private router: Router,  private location1: Location) {}

  ngOnInit(): void {
    this.getAllPublic();
    this.getAllCases();

    this.route.url.subscribe((url) => {
      if (url[0].path === 'signup') {
        this.isSignUpPage = true;
        this.isSignInPage = false;
      } else if (url[0].path === 'PublicPortalSignin') {
        this.isSignInPage = true;
        this.isSignUpPage = false;
        if(this.userLoggedIn==true){
          url[0].path = 'userSignedIn';
        }
      } 
    });
  }

  getAllPublic(){
    this.http.get("http://localhost:4000/api/v1/publicportal").subscribe((res:any)=>{
      // console.log(res);
      this.publicList = res;
    },
    (err)=>{
      // console.log("Error in recieving the api",err);
    }
   );
  }

  onSubmit(): void{

    this.loading = true;
    this.passwordError = false;
    this.otpError = false;

    const user = this.publicList.find((u) => u.email === this.email);
    
  if (user) {
    if (user.password === this.password) {
      this.isAuthenticated = true;
      this.passwordError = false;
      this.userName = user.name;
      this.userEmail = user.email;
      this.userPhoneNumber = user.phoneNumber;
      this.userAge = user.age;
      this.userAddress = user.address;
      this.userState = user.state;
    } else {
      this.passwordError = true;
      this.isAuthenticated = false;
    }
  } else {
    this.passwordError = true;
    this.isAuthenticated = false;
  }

  if (this.isAuthenticated && this.otp) {
    if (this.otp === this.theOtp) {
      this.IsuserLoggedIn();
      this.location1.replaceState('/userSignIn');
      // this.router.navigate(['/publicHomePage']);
      this.otpError = false; 
    } else {
      this.otpError = true;
      // console.log("Incorrect OTP");
    }
  }
    this.loading = false;

  }

  generateOtp(): string {
    const otp = Math.floor(100000 + Math.random() * 900000);
    this.theOtp = otp.toString();
    // console.log('Generated OTP: ', this.theOtp);
    return this.theOtp; 
  }

  sendOtp(): void {
    if (this.isAuthenticated) {
      if (this.theOtp) {
        alert(`The OTP is ${this.theOtp}`);  
        // console.log(`${this.theOtp}`); 
      } else {
        // console.log('OTP not generated yet');
      }
    } else {
      // console.log('User not authenticated');
    }
  }

  triggerOtpProcess(): void {
    this.generateOtp(); 
    this.sendOtp();  
  }

  private resetErrors(): void {
    this.nameError = '';
    this.emailError = '';
    this.passwordError1 = '';
    this.phoneError = '';
    this.ageError = '';
    this.addressError = '';
    this.stateError = '';
  }



  validateSignupForm(): boolean {
    let isValid = true;
  
    this.resetErrors();
        if (!this.name.trim()) {
        this.nameError = 'Name is required!';
        isValid = false;
      }
  
      const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
      if (!this.email.trim() || !emailPattern.test(this.email)) {
        this.emailError = 'Invalid email format!';
        isValid = false;
      }
  
      if (!this.password.trim()) {
        this.passwordError1 = 'Password is required!';
        isValid = false;
      }
  
      const phonePattern = /^\d{10}$/;
      if (!this.phoneNumber.trim() || !phonePattern.test(this.phoneNumber)) {
        this.phoneError = 'Phone number must be 10 digits long!';
        isValid = false;
      }
  
      if (this.age == null || isNaN(this.age) || this.age <= 0 || this.age > 120) {
        this.ageError = 'Please enter a valid age!';
        isValid = false;
      }
  
      if (!this.address.trim()) {
        this.addressError = 'Address is required!';
        isValid = false;
      }
  
      if (!this.state.trim()) {
        this.stateError = 'Please select a state!';
        isValid = false;
      
  
    }
    
    return isValid;
  }
  
  
  isFormValid(): boolean {
    return this.validateSignupForm();
  }


  postForm(): void {

    const formData = {
      name: this.name,
      email: this.email,
      password: this.password,
      phoneNumber: this.phoneNumber,
      age: this.age,
      address:this.address,
      state: this.state
    };

    this.userName = formData.name;
    this.userEmail = formData.email;
    this.userPassword = formData.address;
    this.userPhoneNumber = formData.phoneNumber
    this.userAge = formData.age;
    this.userAddress = formData.address;
    this.userState = formData.state;


    this.http.post("http://localhost:4000/api/v1/publicportal", formData).subscribe(
      (response) => {
        // console.log('Form submitted successfully:', response);
      },
      (error) => {
        // console.error('Error submitting form:', error);
      }
    );

    this.isAuthenticated = true;

    this.otpVerficationSignUp();
  }

  otpVerficationSignUp(){

    this.triggerOtpProcess();

    this.isSignUpPressed = true;
    this.isSignUpPage = false;
    this.isAuthenticated = true;
  }


  enterButtonForSignUp(){

    this.otpError = false;
    if(this.otp===this.theOtp){  
      this.IsuserLoggedIn();
      this.location1.replaceState('/userSignIn');
      this.otpError = false;
    }
    else{
      this.otpError = true;
    }
  }

  IsuserLoggedIn(){
    this.userLoggedIn=true;
    this.isSignUpPressed=false;
    // this.isSignUpPage=false;
    this.isSignInPage=false;
  }

  openProfileCard(){
    this.profileCard = true;
  
    // this.router.navigate(['/signin/publicProfile']);
  }

  closeProfileCard(){
    this.profileCard = false;
  }

  openCaseFillingForm(){
    this.isOpenCaseForm = true;
  }

  closeCasefilligCard(){
    this.isOpenCaseForm = false;
  }


  getAllCases(){
    this.http.get("http://localhost:4000/api/v1/caseportal").subscribe((res:any)=>{
      console.log(res);
      this.caseList = res;
      this.filterUserCases();
    },
    (err)=>{
      // console.log("Error in recieving case api",err);
    }
   );
  }


  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0]; 
  }

  postAllCases(): void {
    if(this.email==this.email1){
      const caseFormData = new FormData(); 
      caseFormData.append('email', this.email1);
      caseFormData.append('case_title', this.case_title);
      caseFormData.append('case_type', this.case_type);
      caseFormData.append('description', this.description);
      caseFormData.append('location', this.location);
      caseFormData.append('case_status', this.case_status);

      if (this.selectedFile) {
        caseFormData.append('evidence', this.selectedFile, this.selectedFile.name);
      }

      this.http.post('http://localhost:4000/api/v1/casePortal', caseFormData).subscribe(
        (response) => {
          // console.log('FIR successfully submitted:', response);
          alert('FIR has been filed successfully')
        },
        (error) => {
          // console.error('Error in submitting FIR:', error);
          alert(`FIR submission failed ${error}`)
        }
      );
      this.firEmailError=false;
      this.isOpenCaseForm=false;
    }else{
      this.firEmailError=true;      
    }
    
  }

  updateUserCases(userEmail: string): void {
    this.email = userEmail; 
    this.filterUserCases();   
  }

  filterUserCases(): void {
    if (this.email) {
      this.getAllCases();
      this.userCaseList = this.caseList.filter(caseData => caseData.email === this.email);
    }
  }

  isViewcase(){
    this.viewCases = true;
    this.updateUserCases(this.email);
    // console.log(this.caseList);
    this.userLoggedIn = false;
    // console.log(this.viewCases)
  }

  closeViewCase(){
    this.viewCases = false;
    this.userLoggedIn = true;
  }

  deleteCase(id:Number){
    this.http.delete(`http://localhost:4000/api/v1/caseportal/${id}`)
    .subscribe(
      (res: any) => {
        // console.log('FIR deleted successfully', res);
        this.getAllCases();
      },
      (err) => {
        // console.error('Error Deleting FIR:', err);
      }
    );
  }


  toShowAllLaws(){
    this.showAllLaws = true;
    this.userLoggedIn = false;
  }

  notShowLaws(){
    this.showAllLaws = false;
    this.userLoggedIn = true;
  }

}


