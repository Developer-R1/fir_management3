import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { HomePageComponent } from './app/home-page/home-page.component';
import { PolicePortalComponent } from './app/police-portal/police-portal.component';
import { PublicPortalComponent } from './app/public-portal/public-portal.component';
import { AppComponent } from './app/app.component';


bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
